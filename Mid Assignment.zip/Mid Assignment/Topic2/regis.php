<?php

	$empty1 = 0;
	$empty2 = 0;
	$empty3 = 0;
	$empty4 = 0;
	$invalid1=0;
	$invalid2=0;
	$invalid3=0;
	
	$f_name = "";
	$l_name = "";
	$email = "";
	$gender_name = "";
	$date1 = "";
	$date2 = "";
	$date3 = "";

	if(isset($_GET['submit']))
	{
		$f_name =  $_GET['first_name'];
		$l_name =  $_GET['last_name'];
		$email =  $_GET['email'];
		$gender_name =  $_GET['gender']; //if there is no radio button input for gender, it will show undefined index after submission
		$date1 =  $_GET['date1'];
		$date2 =  $_GET['date2'];
		$date3 =  $_GET['date3'];
		
		//First name and last name validation
		if($f_name == null || $l_name == null)
		{
			$empty1 = 1;
		}else
		{
			$arr1 = str_split($f_name);
			$first_leter_validation=0;
			foreach ($arr1 as $ccc)
			{
				if($first_leter_validation==0)
				{
					$first_leter_validation=1;
					if($ccc=='.' || $ccc=='-')
					{
						$invalid1=1;
					}
				}
				$v=0;
				for($a='A';$a<'Z';$a++)
				{
					if($a==$ccc)
					{
						$v=1;
						break;
					}
					
				}
				if($ccc=='Z')
				{
					$v=1;
				}
				if($v==0)
				{
					for($a='a';$a<'z';$a++)
					{
						if($a==$ccc)
						{
							$v=1;
							break;
						}
					}
				}
				if($ccc=='z')
				{
					$v=1;
				}
				if($ccc=='.')
				{
					$v=1;
				}
				if($ccc=='-')
				{
					$v=1;
				}
				if($v==0)
				{
					$invalid1=1;
				}
			}
			$arr1 = str_split($l_name);
			$first_leter_validation=0;
			foreach ($arr1 as $ccc)
			{
				if($first_leter_validation==0)
				{
					$first_leter_validation=1;
					if($ccc=='.' || $ccc=='-')
					{
						$invalid1=1;
					}
				}
				$v=0;
				for($a='A';$a<'Z';$a++)
				{
					if($a==$ccc)
					{
						$v=1;
						break;
					}
					
				}
				if($ccc=='Z')
				{
					$v=1;
				}
				if($v==0)
				{
					for($a='a';$a<'z';$a++)
					{
						if($a==$ccc)
						{
							$v=1;
							break;
						}
					}
				}
				if($ccc=='z')
				{
					$v=1;
				}
				if($ccc=='.')
				{
					$v=1;
				}
				if($ccc=='-')
				{
					$v=1;
				}
				if($v==0)
				{
					$invalid1=1;
				}
			}
		}
		//Email Validation
		if($email == null)
		{
			$empty2 = 1;
		}else
		{
			$a = strpos($email, "@");
			$b = strpos($email, ".com");
			if($a==null)
			{
				$invalid2=1;
			}
			if($b==null)
			{
				$invalid2=1;
			}
			if($a>$b)
			{
				$invalid2=1;
			}
		}
		//Date of birth validation
		if($date1 == null || $date2 == null || $date3 == null)
		{
			$empty3 = 1;
		}else
		{
			if($date1<1 || $date1>31)
			{
				$invalid3=1;
			}
			if($date2<1 || $date2>12)
			{
				$invalid3=1;
			}
			if($date3<1900 || $date3>2016)
			{
				$invalid3=1;
			}
		}
		//Gender Validation
		if($gender_name==null)
		{
			$empty4=1;
		}
	}
?>

<html>
<head>
  <title>Registration</title>
</head>
<body>
	<form>
		<div style="padding-top: 85px;background: #3C5A99;">
		</div>
		<div style="padding-left: 100px;background: #E9EBEE;padding-top: 30px;padding-bottom: 100px;">
		<div style="float: left;padding-left: 70px;padding-top: 100px;">
			<img src="fb.png">
		</div>
		<div>
		<table style="padding-left: 80px;">
			<tr>
				<td colspan="3">
					<h1>Create a new account</h1>
				</td>
			</tr>
			<tr>
				<td>
					<input font-size="200px" type="text" name="first_name" placeholder="First Name" style="font-size: 16px; border: none; border-bottom-color: #A4A4A4; height: 40px;border-radius: 5px;padding-left: 5px;">
				</td>
				<td>
					<input type="text" name="last_name" placeholder="Last Name" style="font-size: 16px; border: none; border-bottom-color: #A4A4A4; height: 40px;border-radius: 5px;padding-left: 5px;">
				</td>
				<td>
					<?php if($empty1 == 1){ echo "<p style='color: red;'>Can't be empty</p>";}?>
					<?php if($invalid1==1)
					{
						echo "<p style='color: red;'>Invalid</p>";
					}
					?>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="text" name="email" placeholder="Email address" size="45px" style="font-size: 16px; border: none; border-bottom-color: #A4A4A4; height: 40px;border-radius: 5px;padding-left: 5px;">
				</td>
				<td>
					<?php if($empty2 == 1){ echo "<p style='color: red;'>Can't be empty</p>";}?>
					<?php if($invalid2==1)
					{
						echo "<p style='color: red;'>Invalid</p>";
					}
					?>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="password" name="password1" placeholder="Password" size="45px" style="font-size: 16px; border: none; border-bottom-color: #A4A4A4; height: 40px;border-radius: 5px;padding-left: 5px;">
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="password" name="password2" placeholder="Confirm password" size="45px" style="font-size: 16px; border: none; border-bottom-color: #A4A4A4; height: 40px;border-radius: 5px;padding-left: 5px;">
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="text" name="phone" placeholder="Phone" size="45px" style="font-size: 16px; border: none; border-bottom-color: #A4A4A4; height: 40px;border-radius: 5px;padding-left: 5px;">
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<h3>Birthday</h3>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="number" name="date1" style="width: 40px" value="1">/
					<input type="number" name="date2" style="width: 40px" value="12">/
					<input type="number" name="date3" style="width: 55px" value="2000">/<i>(dd/mm/yy)</i>
				</td>
				<td>
					<?php if($empty3 == 1){ echo "<p style='color: red;'>Can't be empty</p>";}?>
					<?php if($invalid3==1)
					{
						echo "<p style='color: red;'>Invalid</p>";
					}
					?>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="radio" name="gender" value = "Male">Male
					<input type="radio" name="gender" value = "Female">Female
					<input type="radio" name="gender" value = "Other">Other
				</td>
				<td>
					<?php 
					
						if($empty4==1)
						{
							echo "<p style='color: red;'>Not Selected</p>";
						}
					
					?>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="submit" name="submit" value="Sign Up" style="font-size: 18px;height: 45px;width: 200px;border-radius: 5px;color: white;background: #67A052;">
				</td>
			</tr>
		</table>
		</div>
		</div>
	</form>
</body>
</html>